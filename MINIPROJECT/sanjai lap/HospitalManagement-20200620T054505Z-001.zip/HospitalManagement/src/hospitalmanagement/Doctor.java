/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospitalmanagement;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

/**
 *
 * @author ELCOT
 */
@Entity
@Table(name = "doctor", catalog = "hospital", schema = "")
@NamedQueries({
    @NamedQuery(name = "Doctor.findAll", query = "SELECT d FROM Doctor d")
    , @NamedQuery(name = "Doctor.findBySsn", query = "SELECT d FROM Doctor d WHERE d.ssn = :ssn")
    , @NamedQuery(name = "Doctor.findByFname", query = "SELECT d FROM Doctor d WHERE d.fname = :fname")
    , @NamedQuery(name = "Doctor.findByLname", query = "SELECT d FROM Doctor d WHERE d.lname = :lname")
    , @NamedQuery(name = "Doctor.findByDob", query = "SELECT d FROM Doctor d WHERE d.dob = :dob")
    , @NamedQuery(name = "Doctor.findByBloodgroup", query = "SELECT d FROM Doctor d WHERE d.bloodgroup = :bloodgroup")
    , @NamedQuery(name = "Doctor.findByGender", query = "SELECT d FROM Doctor d WHERE d.gender = :gender")
    , @NamedQuery(name = "Doctor.findByDept", query = "SELECT d FROM Doctor d WHERE d.dept = :dept")
    , @NamedQuery(name = "Doctor.findByAge", query = "SELECT d FROM Doctor d WHERE d.age = :age")
    , @NamedQuery(name = "Doctor.findByMaritialstatus", query = "SELECT d FROM Doctor d WHERE d.maritialstatus = :maritialstatus")
    , @NamedQuery(name = "Doctor.findByMobileno", query = "SELECT d FROM Doctor d WHERE d.mobileno = :mobileno")
    , @NamedQuery(name = "Doctor.findByExperience", query = "SELECT d FROM Doctor d WHERE d.experience = :experience")
    , @NamedQuery(name = "Doctor.findByAddress", query = "SELECT d FROM Doctor d WHERE d.address = :address")
    , @NamedQuery(name = "Doctor.findByUsername", query = "SELECT d FROM Doctor d WHERE d.username = :username")
    , @NamedQuery(name = "Doctor.findByPassword", query = "SELECT d FROM Doctor d WHERE d.password = :password")})
public class Doctor implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "SSN")
    private Integer ssn;
    @Column(name = "fname")
    private String fname;
    @Column(name = "lname")
    private String lname;
    @Column(name = "dob")
    @Temporal(TemporalType.DATE)
    private Date dob;
    @Column(name = "bloodgroup")
    private String bloodgroup;
    @Column(name = "gender")
    private String gender;
    @Column(name = "dept")
    private String dept;
    @Column(name = "age")
    private Integer age;
    @Column(name = "maritialstatus")
    private String maritialstatus;
    @Column(name = "mobileno")
    private String mobileno;
    @Column(name = "experience")
    private Integer experience;
    @Column(name = "address")
    private String address;
    @Column(name = "username")
    private String username;
    @Column(name = "password")
    private String password;

    public Doctor() {
    }

    public Doctor(Integer ssn) {
        this.ssn = ssn;
    }

    public Integer getSsn() {
        return ssn;
    }

    public void setSsn(Integer ssn) {
        Integer oldSsn = this.ssn;
        this.ssn = ssn;
        changeSupport.firePropertyChange("ssn", oldSsn, ssn);
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        String oldFname = this.fname;
        this.fname = fname;
        changeSupport.firePropertyChange("fname", oldFname, fname);
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        String oldLname = this.lname;
        this.lname = lname;
        changeSupport.firePropertyChange("lname", oldLname, lname);
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        Date oldDob = this.dob;
        this.dob = dob;
        changeSupport.firePropertyChange("dob", oldDob, dob);
    }

    public String getBloodgroup() {
        return bloodgroup;
    }

    public void setBloodgroup(String bloodgroup) {
        String oldBloodgroup = this.bloodgroup;
        this.bloodgroup = bloodgroup;
        changeSupport.firePropertyChange("bloodgroup", oldBloodgroup, bloodgroup);
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        String oldGender = this.gender;
        this.gender = gender;
        changeSupport.firePropertyChange("gender", oldGender, gender);
    }

    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        String oldDept = this.dept;
        this.dept = dept;
        changeSupport.firePropertyChange("dept", oldDept, dept);
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        Integer oldAge = this.age;
        this.age = age;
        changeSupport.firePropertyChange("age", oldAge, age);
    }

    public String getMaritialstatus() {
        return maritialstatus;
    }

    public void setMaritialstatus(String maritialstatus) {
        String oldMaritialstatus = this.maritialstatus;
        this.maritialstatus = maritialstatus;
        changeSupport.firePropertyChange("maritialstatus", oldMaritialstatus, maritialstatus);
    }

    public String getMobileno() {
        return mobileno;
    }

    public void setMobileno(String mobileno) {
        String oldMobileno = this.mobileno;
        this.mobileno = mobileno;
        changeSupport.firePropertyChange("mobileno", oldMobileno, mobileno);
    }

    public Integer getExperience() {
        return experience;
    }

    public void setExperience(Integer experience) {
        Integer oldExperience = this.experience;
        this.experience = experience;
        changeSupport.firePropertyChange("experience", oldExperience, experience);
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        String oldAddress = this.address;
        this.address = address;
        changeSupport.firePropertyChange("address", oldAddress, address);
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        String oldUsername = this.username;
        this.username = username;
        changeSupport.firePropertyChange("username", oldUsername, username);
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        String oldPassword = this.password;
        this.password = password;
        changeSupport.firePropertyChange("password", oldPassword, password);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (ssn != null ? ssn.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Doctor)) {
            return false;
        }
        Doctor other = (Doctor) object;
        if ((this.ssn == null && other.ssn != null) || (this.ssn != null && !this.ssn.equals(other.ssn))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "hospitalmanagement.Doctor[ ssn=" + ssn + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
